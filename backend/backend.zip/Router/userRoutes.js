import express from "express";
const userRoute = express.Router();
import {
  userList,
  singleUser,
  removeUSer,
} from "../controller/userController.js";

userRoute.get("/userList", userList);
userRoute.get("/singleuser/:id", singleUser);
userRoute.delete("/deleteuser/:id", removeUSer);

export default userRoute;
