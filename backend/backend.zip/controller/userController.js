import User from "../model/userModel.js";
export const userList = async (req, res) => {
  try {
    const allUser = await User.find();
    if (!allUser) {
      return res.status(404).json({ msg: "no user found" });
    }
    return res.status(200).json({ allUser });
  } catch (error) {
    return res.status(404).json({ msg: error.message });
  }
};
export const singleUser = async (req, res) => {
  try {
    const id = req.params.id;
    const oneUSer = await User.findById(id);
    if (!oneUSer) {
      return res.status(404).json({ msg: "no such user exists" });
    }
    return res.status(200).json({ oneUSer });
  } catch (error) {
    return res.status(404).json({ msg: error.message });
  }
};

export const removeUSer = async (req, res) => {
  try {
    const id = req.params.id;
    console.log(id);

    const removeUser = await User.findById(id);
    if (!removeUser) {
      return res.status(404).json({ msg: "no user found" });
    }
    await User.findByIdAndDelete(id);
    res.status(200).json({ message: "user deleted successfully" });
  } catch (error) {
    return res.status(500).json({ msg: error.message });
  }
};
